﻿using System;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;
using AcceptEmail.WebServices.ClientLibrary.AeApi;
using System.Web.UI.HtmlControls;

public partial class CreateBatch : System.Web.UI.Page
{
    
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            BindProductDDL();
            Session["ProductID"] = productsDDL.SelectedValue;
            BindAETemplatesDDL();
        }
        (Page.Master.FindControl("BodyTag") as HtmlControl).Attributes.Add("class", "batchcreate");
    }


    protected void BindProductDDL()
    {
        productsDDL.Items.Clear();
        foreach (var product in AEServiceClient.Products.ToList())
        {
            productsDDL.Items.Add(new ListItem(product.Description, product.Id.ToString()));
        }
        productsDDL.DataBind();
    }

    protected void BindAETemplatesDDL()
    {
        AEServiceClient aeServiceClient = new AEServiceClient();
        
        var getAETemplatesResponse = aeServiceClient.GetAcceptEmailTemplates(new GetAcceptEmailTemplatesRequestType()
        {
            ProductID = new Guid((string)Session["ProductID"])
        });

        if (getAETemplatesResponse.Error != null)
        {
            errorLbl.Text += "Could not get AE Templates from the service: [" 
                +getAETemplatesResponse.Error.Code+"] "
                + getAETemplatesResponse.Error.Description;
        }
        else
        {
            aeTemplatesDDL.Items.Clear();
            foreach (var aeTemplate in getAETemplatesResponse.AcceptEmailTemplates)
            {
                aeTemplatesDDL.Items.Add(new ListItem(aeTemplate.AcceptEmailTemplateName, aeTemplate.AcceptEmailTemplateID.ToString()));
            }
            aeTemplatesDDL.DataBind();
        }
    }
    protected void productsDDL_SelectedIndexChanged(object sender, EventArgs e)
    {
        Session["ProductID"] = ((DropDownList)sender).SelectedValue;
        BindAETemplatesDDL();
    }
    protected void CreateButton_Click(object sender, EventArgs e)
    {
        AEServiceClient aeServiceClient = new AEServiceClient();
        
        RecordRequest recordRequest = new RecordRequest()
        {
            Amount = new Amount()
            {
                Value = amountTxt.Text,
                SchemeID = String.Empty
            },
            CountdownDays = Int32.Parse(countDownDaysTxt.Text),
            Currency = currencyTxt.Text,
            DateTime = DateTime.Parse(expirationDateTxt.Text),
            Description = descriptionTxt.Text,
            EmailAddress = custEmailTxt.Text,
            PaymentReference = paymentReferenceTxt.Text,
            SenderRecordReferenceID = srridTxt.Text
        };

        CreateBatchRequestType createBatchRequest = new CreateBatchRequestType()
        {
            BatchValues = new BatchValues()
            {
                AcceptEmailTemplateID = new Guid(aeTemplatesDDL.SelectedValue),
                ProductID = new Guid((string)Session["ProductID"])
            },
            SenderBatchReferenceID = senderBatchReferenceIDTxt.Text,
            Records = new RecordRequest[] { recordRequest }
        };
        CreateBatchResponseType createBatchResponse =  aeServiceClient.CreateBatch(createBatchRequest);
        if (createBatchResponse.Error != null)
        {
            errorLbl.Text = !String.IsNullOrEmpty(createBatchResponse.Error.Description) ? createBatchResponse.Error.Description : "Error in creating a batch";
        }
        else
        {
            Session["BatchID"] = createBatchResponse.Response.BatchID;
            Session["SenderBatchReferenceID"] = senderBatchReferenceIDTxt.Text;
            Response.Redirect("~/SendBatch.aspx");
        }
    }

}

