﻿using AcceptEmail.WebServices.ClientLibrary.Interfaces;

/// <summary>
/// Summary description for Logger
/// </summary>
public class Logger : IMessageLog
{
	public Logger()
	{
		//
		// TODO: Add constructor logic here
		//
	}

	public void InputMessage(string message)
    {
        //throw new NotImplementedException();
    }

	public void OutputMessage(string message)
    {
		//throw new NotImplementedException();
	}

	public void Info(string message)
	{
		//throw new NotImplementedException();
	}
}