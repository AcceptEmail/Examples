﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

/// <summary>
/// Summary description for RecordStatistics
/// </summary>
public class RecordStatistics
{
    public Guid RecordATID { get; set; }
    public uint StatusID { get; set; }
    public DateTime? LastChangeDateTime { get; set; }
    public DateTime? LastClickDateTime { get; set; }
    public DateTime? LastViewDateTime { get; set; }
    public uint? NumberOfClicks { get; set; }
    public uint? NumberOfViews { get; set; }
}