﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using log4net;
using AcceptEmail.WebServices.ClientLibrary.AeApi;
using System.Web.UI.HtmlControls;

[assembly: log4net.Config.XmlConfigurator(ConfigFile = "log4net.config", Watch = true)]
public partial class StatusRequest : System.Web.UI.Page
{
    static ILog log = LogManager.GetLogger(typeof(StatusRequest));
   
    protected void Page_Load(object sender, EventArgs e)
    {
        (Page.Master.FindControl("BodyTag") as HtmlControl).Attributes.Add("class", "batchstatus");
    }

    protected void GetStatusBtn_Click(object sender, EventArgs e)
    {
       
        Guid batchID;
        if (Guid.TryParse(batchIDTxt.Text, out batchID))
        {
            AEServiceClient aeServiceClient = new AEServiceClient();
            var statusRequest = new GetRecordsStatusRequestType()
            {
                Item = batchID,
                ReturnDetails = detailsCB.Checked
            };
  
            var statusResponse = aeServiceClient.GetRecordsStatus(statusRequest);
            if (statusResponse.Error == null)
            {


                recordsGridView.Columns[2].Visible = true;
                recordsGridView.Columns[3].Visible = true;
                recordsGridView.Columns[4].Visible = true;
                recordsGridView.Columns[5].Visible = true;
                recordsGridView.Columns[6].Visible = true;

                var records = new List<RecordStatistics>();
                foreach (var record in statusResponse.Records)
                {
                    //responseLbl.Text += record.RecordATID + " - " + record.StatusID;
                    var recordStats = new RecordStatistics();
                    recordStats.RecordATID = record.RecordATID;
                    recordStats.StatusID = record.StatusID;
                    if (detailsCB.Checked)
                    {
                        recordStats.LastChangeDateTime = record.Details.LastChangeDateTime;
                        recordStats.LastClickDateTime = record.Details.LastClickDateTime;
                        recordStats.LastViewDateTime = record.Details.LastViewDateTime;
                        recordStats.NumberOfClicks = record.Details.NumberOfClicks;
                        recordStats.NumberOfViews = record.Details.NumberOfViews;
                    }
                    records.Add(recordStats);
                }
                recordsGridView.Visible = true;
                recordsGridView.DataSource = records;
                recordsGridView.DataBind();
                if (!detailsCB.Checked)
                {
                    recordsGridView.Columns[2].Visible = false;
                    recordsGridView.Columns[3].Visible = false;
                    recordsGridView.Columns[4].Visible = false;
                    recordsGridView.Columns[5].Visible = false;
                    recordsGridView.Columns[6].Visible = false;
                }
                errorLbl.Text = "";
            }
            else
            {
                errorLbl.Text = !String.IsNullOrEmpty(statusResponse.Error.Description) ? statusResponse.Error.Description : "Error in creating a batch";
            }
        }
        else
        {
            errorLbl.Text = "Invalid Batch ID";
        }

    }

    protected void GetStatusBtn_PreRender(object sender, EventArgs e)
    {
        if (Session["BatchID"] != null)
        {
            batchIDTxt.Text = ((Guid)Session["BatchID"]).ToString();
        }
    }
}