﻿using System;
using System.Web.UI.HtmlControls;

public partial class _Default : System.Web.UI.Page
{
	protected void Page_Load(object sender, EventArgs e)
	{
        (Page.Master.FindControl("BodyTag") as HtmlControl).Attributes.Add("class", "batchdefault");
	}
 
}
