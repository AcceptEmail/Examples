﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AcceptEmail.WebServices.ClientLibrary.AeApi;
using System.Web.UI.HtmlControls;


public partial class SendBatch : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            BindEmailTemplatesDDL();
        }
        (Page.Master.FindControl("BodyTag") as HtmlControl).Attributes.Add("class", "batchsend");
    }
    protected void SendBatchBtn_Click(object sender, EventArgs e)
    {
        AEServiceClient aeServiceClient = new AEServiceClient();
        var sendBatchRequest = new SendBatchRequestType();
        sendBatchRequest.SenderBatchReferenceID = senderBatchReferenceIDTxt.Text;
        sendBatchRequest.EmailTemplateID = emailTemplatesDDL.SelectedValue;
        var sendBatchResponse = aeServiceClient.SendBatch(sendBatchRequest);
        if (sendBatchResponse.Success)
        {
            Response.Redirect("~/StatusRequest.aspx");
        }
        else
        {
            errorLbl.Text = !String.IsNullOrEmpty(sendBatchResponse.Error.Description) ? sendBatchResponse.Error.Description : "Error in creating a batch";
        }
    }
    protected void senderBatchReferenceIDTxt_PreRender(object sender, EventArgs e)
    {
        if (!String.IsNullOrEmpty((string)Session["SenderBatchReferenceID"]))
        {
            senderBatchReferenceIDTxt.Text = (string)Session["SenderBatchReferenceID"];
        }
    }

    protected void BindEmailTemplatesDDL()
    {
        AEServiceClient aeServiceClient = new AEServiceClient();
        var getEmailTemplatesResponse = aeServiceClient.GetEmailTemplates();

        if (getEmailTemplatesResponse.Error != null)
        {
            errorLbl.Text += "Could not get AE Templates from the service: ["
                + getEmailTemplatesResponse.Error.Code + "] "
                + getEmailTemplatesResponse.Error.Description;
        }
        else
        {
            emailTemplatesDDL.Items.Clear();
            foreach (var emailTemplate in getEmailTemplatesResponse.EmailTemplates)
            {
                emailTemplatesDDL.Items.Add(new ListItem(emailTemplate.Name, emailTemplate.ID.ToString()));
            }
            emailTemplatesDDL.DataBind();
        }
    }
    protected void productsDDL_SelectedIndexChanged(object sender, EventArgs e)
    {

        BindEmailTemplatesDDL();
    }

    protected void emailTemplatesDDL_SelectedIndexChanged(object sender, EventArgs e)
    {

    }
}