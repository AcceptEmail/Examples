﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AcceptEmail.WebServices.ClientLibrary.AeApi;
using System.Web.UI.HtmlControls;

public partial class CreateMandateBatch : System.Web.UI.Page
{
    public  const string ProductID = "78D77D31-EE09-474E-81FF-ABB3393BAE11";

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack) 
        {
            BindAETemplatesDDL();
        }
        (Page.Master.FindControl("BodyTag") as HtmlControl).Attributes.Add("class", "mandatecreate");
    }

    protected void BindAETemplatesDDL()
    {
        AEServiceClient aeServiceClient = new AEServiceClient();

        var getAETemplatesResponse = aeServiceClient.GetAcceptEmailTemplates(new GetAcceptEmailTemplatesRequestType()
        {
            ProductID = new Guid(ProductID)
        });

        if (getAETemplatesResponse.Error != null)
        {
            errorLbl.Text += "Could not get Mandate AE Templates from the service: ["
                + getAETemplatesResponse.Error.Code + "] "
                + getAETemplatesResponse.Error.Description;
        }
        else
        {
            aeTemplatesDDL.Items.Clear();
            foreach (var aeTemplate in getAETemplatesResponse.AcceptEmailTemplates)
            {
                aeTemplatesDDL.Items.Add(new ListItem(aeTemplate.AcceptEmailTemplateName, aeTemplate.AcceptEmailTemplateID.ToString()));
            }
            aeTemplatesDDL.DataBind();
        }
    }

    protected void CreateButton_Click(object sender, EventArgs e)
    {
        AEServiceClient aeServiceClient = new AEServiceClient();
        var amountType = "Open";
        var sequenceType = "OneOff";
        DateTime? toDate = null;

        if (!String.IsNullOrEmpty(collectionAmountTxt.Text) && String.IsNullOrEmpty(maximumAmountTxt.Text))
            amountType = "Fixed";
        if (!String.IsNullOrEmpty(maximumAmountTxt.Text) && String.IsNullOrEmpty(collectionAmountTxt.Text))
            amountType = "Maximum";

        if (!String.IsNullOrEmpty(expirationDateTxt.Text))
            sequenceType = "Recurring";

         if (!String.IsNullOrEmpty(expirationDateTxt.Text))
            toDate = DateTime.Parse(expirationDateTxt.Text);

        var srrID = DateTime.Now.Ticks.ToString("X2");
        bool collectionAmountSpecified = !String.IsNullOrEmpty(collectionAmountTxt.Text);
        bool maximumAmountSpecified = !String.IsNullOrEmpty(maximumAmountTxt.Text);
        bool firstInstallmentSpecified = !String.IsNullOrEmpty(firstInstallmentTxt.Text);

        var record = new BasicMandateRecordRequest
        {
            EmailAddress = custEmailTxt.Text,
            PaymentReference = paymentReferenceTxt.Text,
            SenderRecordReferenceID = srrID,
            Description = descriptionTxt.Text,
            CollectionAmountSpecified = collectionAmountSpecified,
            CollectionAmount = collectionAmountSpecified ? Convert.ToDecimal(collectionAmountTxt.Text) : 0,
            MaximumAmountSpecified = maximumAmountSpecified,
            MaximumAmount = maximumAmountSpecified ? Convert.ToDecimal(maximumAmountTxt.Text) : 0,
            AmountType = amountType,
            SequenceType = sequenceType,
            ToDate = toDate,
            MandateReference = referenceTxt.Text,
            FirstInstallmentSpecified = firstInstallmentSpecified,
            FirstInstallment = firstInstallmentSpecified ? Convert.ToDecimal(firstInstallmentTxt.Text) : Convert.ToDecimal(0.01),

        };

        var request = new CreateBasicMandateBatchRequestType
        {
            SenderBatchReferenceID = senderBatchReferenceIDTxt.Text,
            BasicMandateRecords = new[] { record },
            BasicMandateBatchValues = new BasicMandateBatchValues
            {
                AcceptEmailTemplateID = new Guid(aeTemplatesDDL.SelectedValue)
            }
        };

        CreateBasicMandateBatchResponseType createMandateBatchResponse = aeServiceClient.CreateBasicMandateBatch(request);
        if (createMandateBatchResponse.Error != null)
        {
            errorLbl.Text = !String.IsNullOrEmpty(createMandateBatchResponse.Error.Description) ? createMandateBatchResponse.Error.Description : "Error in creating a mandate batch";
        }
        else
        {
            Session["MandateBatchID"] = createMandateBatchResponse.Response.BatchID;
            Session["MandateSRRID"] = srrID;
            Response.Redirect("~/MandateDetails.aspx");
        }

    }

}

