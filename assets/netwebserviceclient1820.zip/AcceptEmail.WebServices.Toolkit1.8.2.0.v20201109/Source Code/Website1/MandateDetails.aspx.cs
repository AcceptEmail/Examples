﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AcceptEmail.WebServices.ClientLibrary.AeApi;
using log4net;
using System.Web.UI.HtmlControls;

public partial class MandateDetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        (Page.Master.FindControl("BodyTag") as HtmlControl).Attributes.Add("class", "mandatedetails");
    }

    protected void GetDetailsBtn_Click(object sender, EventArgs e)
    {      
        Guid batchID;
        if (Guid.TryParse(batchIDTxt.Text, out batchID))
        {
            AEServiceClient aeServiceClient = new AEServiceClient();

            var request = new GetMandateBatchRecordsRequestType
            {
                Item = batchID
            };

            var statusResponse = aeServiceClient.GetMandateBatchRecords(request);

            if (statusResponse.Error == null)
            {
                recordsGridView.Columns[0].Visible = true;
                recordsGridView.Columns[1].Visible = true;
                recordsGridView.Columns[2].Visible = true;
                recordsGridView.Columns[3].Visible = true;

                var records = new List<MandateRecordStatistics>();
                foreach (var record in statusResponse.Response.Records)
                {
                    var recordStats = new MandateRecordStatistics();
                    recordStats.SenderRecordReferenceID = record.SenderRecordReferenceID;
                    recordStats.RecordATID = record.RecordATID;
                    recordStats.ImageURL = record.ImageURL;
                    recordStats.TransactionURL = record.TransactionURL;

                    records.Add(recordStats);
                }
                recordsGridView.Visible = true;
                recordsGridView.DataSource = records;
                recordsGridView.DataBind();
                errorLbl.Text = "";
            }
            else
            {
                errorLbl.Text = !String.IsNullOrEmpty(statusResponse.Error.Description) ? statusResponse.Error.Description : "Error in geting a mandate batch";
            }
        }
        else
        {
            errorLbl.Text = "Invalid Mandate Batch ID";
        }
    }

    protected void GetDetailsBtn_PreRender(object sender, EventArgs e)
    {
        if (Session["MandateBatchID"] != null)
        {
            batchIDTxt.Text = ((Guid)Session["MandateBatchID"]).ToString();
        }      
    }
}