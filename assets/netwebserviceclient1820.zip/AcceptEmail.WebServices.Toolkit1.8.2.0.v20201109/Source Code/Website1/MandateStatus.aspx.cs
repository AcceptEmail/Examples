﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using AcceptEmail.WebServices.ClientLibrary.AeApi;
using System.Web.UI.HtmlControls;

public partial class MandateStatus : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        (Page.Master.FindControl("BodyTag") as HtmlControl).Attributes.Add("class", "mandatestatus");
    }

    protected void GetStatusBtn_Click(object sender, EventArgs e)
    {
        if (!String.IsNullOrEmpty(srrIDTxt.Text))
        {
            var srv = new AEServiceClient();

            try
            {
                var response = srv.GetMandates(new GetMandatesRequestType()
                {
                    ResultType = GetMandatesRequestResultType.Status,
                    IdListType = GetMandatesRequestMandateIdListType.RecordReferenceIds,
                    IdListTypeSpecified = true,
                    IdList = new string[] { srrIDTxt.Text },
                });

                recordsGridView.Columns[0].Visible = true;
                recordsGridView.Columns[1].Visible = true;

                var records = new List<MandateRecordStatistics>();

                if (response.Error == null)
                {
                    var record = new MandateRecordStatistics();

                    record.MandateID = srrIDTxt.Text;
                    record.Status = response.StatusResponse.Mandates[0].Status;

                    records.Add(record);

                    recordsGridView.Visible = true;
                    recordsGridView.DataSource = records;
                    recordsGridView.DataBind();
                    errorLbl.Text = "";
                }
                else
                {
                    errorLbl.Text = !String.IsNullOrEmpty(response.Error.Description) ? response.Error.Description : "Error in geting a mandate status";
                }
            }
            catch (Exception ex)
            {
                errorLbl.Text = ex.Message;
            }
        }
        else
        {
            errorLbl.Text = "Invalid SRRID";
        }
    }

    protected void GetStatusBtn_PreRender(object sender, EventArgs e)
    {
        if (Session["MandateSRRID"] != null)
        {
            srrIDTxt.Text = Session["MandateSRRID"].ToString();
        }
    }
}