﻿using System;
using AcceptEmail.WebServices.ClientLibrary.Interfaces;

namespace AcceptEmail.WebServices.ClientSample
{
	class DumpMessagesLog : IMessageLog
	{
		public void InputMessage(string message)
		{
			Console.WriteLine("Request message:" + message);
		}

		public void OutputMessage(string message)
		{
			Console.WriteLine("Receive message:" + message);
		}

        public void Info(string message)
        {
            Console.WriteLine("Info message:" + message);
        }
    }
}
