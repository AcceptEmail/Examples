﻿using AcceptEmail.WebServices.ClientLibrary.AeApi;

namespace AcceptEmail.WebServices.ClientSample
{
	class Program
	{
        static void Main(string[] args)
		{
            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;

            using (AEServiceClient client1 = new AEServiceClient())
			{
				GetAtTemplates(client1);
			}

			using (AEServiceClient client2 = new AEServiceClient(new DumpMessagesLog()))
			{
				GetAtTemplates(client2);
			}
			return;
		}

		static void GetAtTemplates(IAEService client)
		{
			var ret = client.GetAcceptEmailTemplates(new GetAcceptEmailTemplatesRequestType()
			{
				ProductID = null
			});

			System.Console.WriteLine(ret);
			if (ret.Error != null)
				System.Console.WriteLine(ret.Error.Description);
		}

	}
}
