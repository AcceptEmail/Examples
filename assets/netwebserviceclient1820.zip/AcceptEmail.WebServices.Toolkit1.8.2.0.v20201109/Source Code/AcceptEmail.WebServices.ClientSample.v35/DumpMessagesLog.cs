﻿using System.Diagnostics;
using AcceptEmail.WebServices.ClientLibrary.Interfaces;
using System;

namespace AcceptEmail.WebServices.ClientSample
{
	class DumpMessagesLog : IMessageLog
	{
		public void InputMessage(string message)
		{
			Console.WriteLine("input message:" + message);
		}

		public void OutputMessage(string message)
		{
			Console.WriteLine("output message:" + message);
		}

        public void Info(string message)
        {
            Console.WriteLine("Info message:" + message);
        }
    }
}
