﻿
using AcceptEmail.WebServices.ClientLibrary.Interfaces;
using AcceptEmail.WebServices.ClientLibrary.Impl.Inspectors;
using System;
namespace AcceptEmail.WebServices.ClientLibrary.AeApi
{
	public partial class AEServiceClient
	{
        ///<Summary>
        /// Constructor
        ///</Summary>
        ///<param name="log">The MessageLog that will be used for logging</param>
		public AEServiceClient(IMessageLog log)
		{
            this.Endpoint.Behaviors.Add(new LoggingMessageInspectorBehaviour(log));
		}

        public static readonly Product[] Products = new Product[] {new Product("Invoicing", new Guid("508F6A8F-BE94-41CB-B116-5F84B1D2057A")),
                                           new Product("Non Profit", new Guid("D1A35C9E-6F2A-484B-B5A0-6539A971B39C")),
                                           new Product("Direct Marketing" ,new Guid("906B8838-735A-42B9-B313-B2EAD11B8E8B"))};

        /// <summary>
        /// Mandate Product
        /// </summary>
        public static readonly Product MandateProduct = new Product("Mandate", new Guid("78D77D31-EE09-474E-81FF-ABB3393BAE11"));

	}

    ///<Summary>
    /// An AcceptEmail Product
    ///</Summary>
    public class Product
    {
        public Product(string description, Guid id)
        {
            this.Description = description;
            this.Id = id;
        }

        ///<Summary>
        /// The Product' Name
        ///</Summary>
        public string Description { get; set; }

        ///<Summary>
        /// The Product's Id
        ///</Summary>
        public Guid Id { get; set; }
    }

    
}
