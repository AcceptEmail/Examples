﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Description;
using AcceptEmail.WebServices.ClientLibrary.Interfaces;

namespace AcceptEmail.WebServices.ClientLibrary.Impl.Inspectors
{
    /// <summary>
    /// LoggingMessageInspectorBehavior class.
    /// </summary>
    public class LoggingMessageInspectorBehaviour : IEndpointBehavior
    {
        /// <summary>
        /// The MessageLog that will be use for logging
        /// </summary>
        private IMessageLog messageLog;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="log">The MessageLog that will be use for logging</param>
        public LoggingMessageInspectorBehaviour(IMessageLog log)
        {
            this.messageLog = log;
        }


        /// <summary>
        /// Implement to pass data at runtime to bindings to support custom behavior.
        /// </summary>
        /// <param name="endpoint">The endpoint to modify.</param>
        /// <param name="bindingParameters">The objects that binding elements require to support the behavior.</param>
        public void AddBindingParameters(ServiceEndpoint endpoint, System.ServiceModel.Channels.BindingParameterCollection bindingParameters)
        {
        }

        /// <summary>
        /// Implements a modification or extension of the client across an endpoint.
        /// </summary>
        /// <param name="endpoint">The endpoint that is to be customized.</param>
        public void ApplyClientBehavior(ServiceEndpoint endpoint, System.ServiceModel.Dispatcher.ClientRuntime clientRuntime)
        {
            LoggingMessageInspector loggingMessageInspector = new LoggingMessageInspector(messageLog);
            clientRuntime.MessageInspectors.Add(loggingMessageInspector);
        }

        /// <summary>
        /// Implements a modification or extension of the service across an endpoint.
        /// </summary>
        /// <param name="endpoint">The endpoint that exposes the contract.</param>
        /// <param name="endpointDispatcher">The endpoint dispatcher to be modified or extended.</param>
        public void ApplyDispatchBehavior(ServiceEndpoint endpoint, System.ServiceModel.Dispatcher.EndpointDispatcher endpointDispatcher)
        {
        }

        /// <summary>
        /// Implement to confirm that the endpoint meets some intended criteria.
        /// </summary>
        /// <param name="endpoint">The endpoint to validate.</param>
        public void Validate(ServiceEndpoint endpoint)
        {
        }
    }
}
