﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Dispatcher;
using AcceptEmail.WebServices.ClientLibrary.Interfaces;
using System.ServiceModel.Channels;
using System.Xml;
using System.IO;
using System.Xml.Linq;
using AcceptEmail.WebServices.ClientLibrary.Impl.Resources;

namespace AcceptEmail.WebServices.ClientLibrary.Impl.Inspectors
{
    /// <summary>
    /// LoggingMessageInspector class.
    /// </summary>
    public class LoggingMessageInspector : IClientMessageInspector
    {
        /// <summary>
        /// The MessageLog that will be use for logging
        /// </summary>
        private IMessageLog messageLog;


        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="log">The MessageLog that will be use for logging</param>
        public LoggingMessageInspector(IMessageLog log)
        {
            this.messageLog = log;
        }

        /// <summary>
        /// Enables inspection or modification of a message after a reply message is received but prior to passing it back to the client application.
        /// </summary>
        /// <param name="reply">The message to be transformed into types and handed back to the client application.</param>
        /// <param name="correlationState">Correlation state data.</param>
        public void AfterReceiveReply(ref System.ServiceModel.Channels.Message reply, object correlationState)
        {
            var copyOFRequest = reply.CreateBufferedCopy(Int32.MaxValue);

            var bodyContentReader = copyOFRequest.CreateMessage().GetReaderAtBodyContents();
            var bodyContentAsXmlDocument = new XmlDocument();
            bodyContentAsXmlDocument.Load(bodyContentReader);
            bodyContentReader.Close();

			messageLog.OutputMessage(bodyContentAsXmlDocument.InnerXml);

            StringBuilder logMessage = new StringBuilder();
            logMessage.AppendLine(String.Format(Resources.Resources.LoggingMessageInspector_AfterReceiveReply_Reply, bodyContentAsXmlDocument.DocumentElement.Name)); //the service that is beeing called
            messageLog.Info(logMessage.ToString());

            reply = copyOFRequest.CreateMessage();
        }

        /// <summary>
        /// Enables inspection or modification of a message before a request message is sent to a service.
        /// </summary>
        /// <param name="request">The message to be sent to the service.</param>
        /// <param name="channel">The  client object channel.</param>
        /// <returns>
        /// The object that is returned as the <paramref name="correlationState "/>argument of the <see cref="M:System.ServiceModel.Dispatcher.IClientMessageInspector.AfterReceiveReply(System.ServiceModel.Channels.Message@,System.Object)"/> method. This is null if no correlation state is used.The best practice is to make this a <see cref="T:System.Guid"/> to ensure that no two <paramref name="correlationState"/> objects are the same.
        /// </returns>
        public object BeforeSendRequest(ref System.ServiceModel.Channels.Message request, System.ServiceModel.IClientChannel channel)
        {
            var copyOFRequest = request.CreateBufferedCopy(Int32.MaxValue);

            var bodyContentReader = copyOFRequest.CreateMessage().GetReaderAtBodyContents();
            var bodyContentAsXmlDocument = new XmlDocument();
            bodyContentAsXmlDocument.Load(bodyContentReader);
            bodyContentReader.Close();

			messageLog.InputMessage(bodyContentAsXmlDocument.InnerXml);
            
            StringBuilder logMessage = new StringBuilder();
            logMessage.AppendLine(String.Format(Resources.Resources.LoggingMessageInspector_BeforeSendRequest_Request, bodyContentAsXmlDocument.DocumentElement.Name)); //the service that is beeing called
            logMessage.AppendLine(Resources.Resources.LoggingMessageInspector_BeforeSendRequest_ParametersText);
            var requestTag = bodyContentAsXmlDocument.DocumentElement.GetElementsByTagName("request");
            if (requestTag.Count == 1)
            {
                foreach (XmlNode child in requestTag[0].ChildNodes)
                {
                    logMessage.AppendLine(String.Format(Resources.Resources.LoggingMessageInspector_BeforeSendRequest_ParametersFormat, child.Name, child.InnerText));
                }
            }
            messageLog.Info(logMessage.ToString());

            request = copyOFRequest.CreateMessage();
            return null;
        }
    }
}
