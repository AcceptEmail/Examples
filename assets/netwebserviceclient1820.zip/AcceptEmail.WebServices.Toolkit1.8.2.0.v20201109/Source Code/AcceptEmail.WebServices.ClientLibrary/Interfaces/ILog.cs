﻿
namespace AcceptEmail.WebServices.ClientLibrary.Interfaces
{

    /// <summary>
    /// Interface that needs to be implemented, in case a user wants to log the applications acctions
    /// </summary>
	public interface IMessageLog
	{
		/// <summary>
		/// Inputs the message.
		/// </summary>
		/// <param name="message">The message.</param>
		void InputMessage(string message);
		/// <summary>
		/// Outpus the message.
		/// </summary>
		/// <param name="message">The message.</param>
		void OutputMessage(string message);
        /// <summary>
        /// Traces the specified message.
        /// </summary>
        /// <param name="message">The message.</param>
        void Info(string message);
	}
}
