using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using AcceptEmail.WebServices.ClientLibrary.AeApi;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace AcceptEmail.WebServices.ClientUnitTests
{
    [TestClass]
    public class AEServiceClientMandateTest
    {
        [TestMethod]
        [TestCategory("Mandates")]
        public void GetMandatesAcceptEmailTemplatesTest()
        {
            //Arrange
            var client = new AEServiceClient();

            //Act
            var response = client.GetAcceptEmailTemplates(
                new GetAcceptEmailTemplatesRequestType
                {
                    ProductID = AEServiceClient.MandateProduct.Id
                });

            //Assert
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.AcceptEmailTemplates);
            Assert.IsNull(response.Error, "An error is returned: " + (response.Error != null ? response.Error.Description : string.Empty));
            Assert.IsTrue(response.AcceptEmailTemplates.Length > 0);
        }

        [TestMethod]
        [TestCategory("Mandates")]
        public void CreateBasicMandateBatchTest()
        {
            // Arrange
            var client = new AEServiceClient();

            CreateBasicMandateBatchRequestType request;
            var response = CallCreateBasicMandateBatch(client, out request);

            // Assert
            Assert.IsNotNull(response, "Response is null.");
            Assert.IsNull(response.Error, "An error is returned: " + (response.Error != null ? response.Error.Description : string.Empty));
            Assert.IsNotNull(response.Response, "Response.Response is null");
            Assert.AreEqual(request.SenderBatchReferenceID, response.Response.SenderBatchReferenceID, "Invalid SenderBatchReferenceID");
            Assert.IsNotNull(response.Response.BatchID, "BatchID is not returned.");
            Assert.IsTrue(response.Response.Records.Length == request.BasicMandateRecords.Length, "No of inserted records is not equal with the sent records.");
        }

        private static CreateBasicMandateBatchResponseType CallCreateBasicMandateBatch(AEServiceClient client, out CreateBasicMandateBatchRequestType request)
        {
            var uniqueReqId = DateTime.Now.ToString("yyMMddHHmmss") + Guid.NewGuid().ToString().Substring(0, 2);

            var record = new BasicMandateRecordRequest
            {
                EmailAddress = "test@dev.abcpress.com",
                PaymentReference = "WSTRef" + uniqueReqId.Substring(10),
                SenderRecordReferenceID = "WSTSrrid" + uniqueReqId.Substring(10),
                Description = "WSTDesc" + uniqueReqId
            };

            // get the first mandate ae template
            var mandateAeTemplate = client.GetAcceptEmailTemplates(
                new GetAcceptEmailTemplatesRequestType
                {
                    ProductID = AEServiceClient.MandateProduct.Id
                }).AcceptEmailTemplates.FirstOrDefault();

            Debug.Assert(mandateAeTemplate != null, "mandateAETemplate != null");
            request = new CreateBasicMandateBatchRequestType
            {
                SenderBatchReferenceID =
                    "WST" + uniqueReqId,
                BasicMandateRecords = new[] { record },
                BasicMandateBatchValues = new BasicMandateBatchValues
                {
                    AcceptEmailTemplateID = mandateAeTemplate.AcceptEmailTemplateID
                }
            };

            // Act
            var response = client.CreateBasicMandateBatch(request);
            return response;
        }

        [TestMethod]
        [TestCategory("Mandates")]
        public void CreateMandateBatchTest()
        {
            // Arrange
            var client = new AEServiceClient();

            var uniqueReqId = DateTime.Now.ToString("yyMMddHHmmss") + Guid.NewGuid().ToString().Substring(0, 2);

            var record = new MandateRecordRequest
            {
                PaymentReference = "WSTRef" + uniqueReqId.Substring(10),
                SenderRecordReferenceID = "WSTSrrid" + uniqueReqId.Substring(10),
                Description = "WSTDesc" + uniqueReqId,
                MandateInitiationRequest = File.ReadAllText("MandateInitiationRequest.xml")
            };

            // get the first mandate ae template
            var mandateAeTemplate = client.GetAcceptEmailTemplates(
                new GetAcceptEmailTemplatesRequestType
                {
                    ProductID = AEServiceClient.MandateProduct.Id
                }).AcceptEmailTemplates.FirstOrDefault();

            Debug.Assert(mandateAeTemplate != null, "mandateAETemplate != null");
            var request = new CreateMandateBatchRequestType
            {
                SenderBatchReferenceID =
                    "WST" + uniqueReqId,
                MandateBatchValues = new MandateBatchValues
                {
                    AcceptEmailTemplateID = mandateAeTemplate.AcceptEmailTemplateID
                },
                MandateRecords = new[] { record }
            };

            // Act
            var response = client.CreateMandateBatch(request);

            // Assert
            Assert.IsNotNull(response, "Response is null.");
            Assert.IsNull(response.Error, "An error is returned: " + (response.Error != null ? response.Error.Description : string.Empty));
            Assert.IsNotNull(response.Response, "Response.Response is null");
            Assert.IsTrue(request.SenderBatchReferenceID == response.Response.SenderBatchReferenceID, "Invalid SenderBatchReferenceID");
            Assert.IsNotNull(response.Response.BatchID, "BatchID is not returned.");
            Assert.IsTrue(response.Response.Records.Length == request.MandateRecords.Length, "No of inserted records is not equal with the sent records.");
        }

        [TestMethod]
        [TestCategory("Mandates")]
        public void GetMandateBatchRecordsTest()
        {
            // Arrange
            var client = new AEServiceClient();

            CreateBasicMandateBatchRequestType createMandateBatchRequest;
            var createMandateBatchResponse = CallCreateBasicMandateBatch(client, out createMandateBatchRequest);

            var request = new GetMandateBatchRecordsRequestType
            {
                Item = createMandateBatchResponse.Response.BatchID
            };

            // Act
            var response = client.GetMandateBatchRecords(request);

            // Assert
            Assert.IsNotNull(response, "Response is null.");
            Assert.IsNull(response.Error, "An error is returned: " + (response.Error != null ? response.Error.Description : string.Empty));
            Assert.IsNotNull(response.Response, "Records Array is null.");

            Assert.IsTrue(response.Response.Records.Count() == createMandateBatchRequest.BasicMandateRecords.Length,
                "The number of returned records does not match the number of sent records");
        }

        [TestMethod]
        [TestCategory("Mandates")]
        public void GetMandatesTest()
        {
            // Arrange
            var client = new AEServiceClient();

            var request = new GetMandatesRequestType
            {
                ValidityStartDate = DateTime.Now.AddYears(-1),
                ValidityEndDate = DateTime.Now,
            };

            // Act
            var response = client.GetMandates(request);

            // Assert
            Assert.IsNotNull(response, "Response is null.");
            Assert.IsNull(response.Error, "An error is returned: " + (response.Error != null ? response.Error.Description : string.Empty));
            Assert.IsNotNull(response.StatusResponse.Mandates, "Mandates Array is null.");
        }

        [TestMethod]
        [TestCategory("Mandates")]
        public void GetMandates_All_StatusResponse_Test()
        {
            // Arrange
            var allMandates = new List<MandateStatusDetails>();
            var client = new AEServiceClient();
            var request = new GetMandatesRequestType()
            {
                ResultType = GetMandatesRequestResultType.Status,
                StartStatusChangeDate = DateTime.Now.AddYears(-2),
                EndStatusChangeDate = DateTime.Now,
            };

            // Act
            var response = client.GetMandates(request);
            var totalRecors = response.StatusResponse.TotalRecords;

            request.TakeSpecified = true;
            request.SkipSpecified = true;
            request.Take = response.StatusResponse.Mandates.Count();

            while (totalRecors > allMandates.Count)
            {
                allMandates.AddRange(response.StatusResponse.Mandates);

                request.Skip = allMandates.Count();
                response = client.GetMandates(request);

                // Assert
                Assert.IsNotNull(response, "Response is null.");
                Assert.IsNull(response.Error, "An error is returned: " + (response.Error != null ? response.Error.Description : string.Empty));
                Assert.IsNotNull(response.StatusResponse.Mandates, "Mandates Array is null.");
            }

            Assert.IsTrue(allMandates.Count > 0, "No mandates were retrieved");
            Assert.IsTrue(allMandates.Count == totalRecors, "Not all mandates were retrieved");
        }

        [TestMethod]
        [TestCategory("Mandates")]
        public void GetMandates_All_FullResponse_Test()
        {
            // Arrange
            var allMandates = new List<MandateFullDetails>();
            var client = new AEServiceClient();
            var request = new GetMandatesRequestType()
            {
                ResultType = GetMandatesRequestResultType.Full,
                StartStatusChangeDate = DateTime.Now.AddYears(-1),
                EndStatusChangeDate = DateTime.Now,
            };

            // Act
            var response = client.GetMandates(request);
            var totalRecors = response.FullResponse.TotalRecords;

            request.TakeSpecified = true;
            request.SkipSpecified = true;
            request.Take = response.FullResponse.Mandates.Count();

            while (totalRecors > allMandates.Count)
            {
                allMandates.AddRange(response.FullResponse.Mandates);

                request.Skip = allMandates.Count();
                response = client.GetMandates(request);

                // Assert
                Assert.IsNotNull(response, "Response is null.");
                Assert.IsNull(response.Error, "An error is returned: " + (response.Error != null ? response.Error.Description : string.Empty));
                Assert.IsNotNull(response.FullResponse.Mandates, "Mandates Array is null.");
            }

            Assert.IsTrue(allMandates.Count > 0, "No mandates were retrieved");
            Assert.IsTrue(allMandates.Count == totalRecors, "Not all mandates were retrieved");
        }

        [TestMethod]
        [TestCategory("Mandates")]
        public void GetMandates_DefaultSet_StatusResponse_Test()
        {
            // Arrange
            var allMandates = new List<MandateStatusDetails>();
            var client = new AEServiceClient();
            var request = new GetMandatesRequestType()
            {
                ResultType = GetMandatesRequestResultType.Status,
                StartStatusChangeDate = DateTime.Now.AddYears(-2),
                EndStatusChangeDate = DateTime.Now,
            };

            // Act
            var response = client.GetMandates(request);

            // Assert
            Assert.IsNotNull(response, "Response is null.");
            Assert.IsNull(response.Error, "An error is returned: " + (response.Error != null ? response.Error.Description : string.Empty));
            Assert.IsNotNull(response.StatusResponse.Mandates, "Mandates Array is null.");
            Assert.IsTrue(response.StatusResponse.Mandates.Count() < response.StatusResponse.TotalRecords, "The response contains all mandates");
        }

        [TestMethod]
        [TestCategory("Mandates")]
        public void UpdateMandateStatus_Records_Test()
        {
            // Arrange
            var client = new AEServiceClient();

            var request = new UpdateMandateRecordsStatusRequestType()
            {
                Item = new MandateStatusUpdateRequest[] { 
                    new MandateStatusUpdateRequest() { RecordATID = new Guid("E707A114-3A50-4AC3-9EE7-A2E48CA0F7CE"), Status = MandateUpdateStatusType.Withdrawn  },// existing mandate ID
                    new MandateStatusUpdateRequest() { RecordATID = new Guid("77BE9768-23E7-4420-BB74-D55679A96707"), Status = MandateUpdateStatusType.Withdrawn  }// existing mandate ID
                }
            };

            // Act
            var response = client.UpdateMandateStatus(request);

            // Assert
            Assert.IsNotNull(response, "Response is null.");
            Assert.IsNull(response.Error, "An error is returned: " + (response.Error != null ? response.Error.Description : string.Empty));
            Assert.AreEqual(2, response.Records.Length, "Not all records were updated");
        }

        [TestMethod]
        [TestCategory("Mandates")]
        public void UpdateMandateStatus_Records_ErrorResponse_Test()
        {
            // Arrange
            var client = new AEServiceClient();

            var request = new UpdateMandateRecordsStatusRequestType()
            {
                Item = new MandateStatusUpdateRequest[] { 
                    new MandateStatusUpdateRequest() { RecordATID = new Guid("2707A114-3A50-4AC3-9EE7-A2E48CA0F7CE"), Status = MandateUpdateStatusType.Withdrawn  },// non existing mandate ID
                    new MandateStatusUpdateRequest() { RecordATID = new Guid("57BE9768-23E7-4420-BB74-D55679A96707"), Status = MandateUpdateStatusType.Withdrawn  }// non existing mandate ID
                }
            };

            // Act
            var response = client.UpdateMandateStatus(request);

            // Assert
            Assert.IsNotNull(response, "Response is null.");
            Assert.IsNotNull(response.Error, "No error was returned");
        }

        [TestMethod]
        [TestCategory("Mandates")]
        public void UpdateMandateStatus_Batch_Test()
        {
            // Arrange
            var client = new AEServiceClient();

            var request = new UpdateMandateRecordsStatusRequestType()
            {
                Item = new BatchMandateStatusUpdateRequest() { BatchID = new Guid("d7fe7c59-4786-4825-8d5d-222bb0e25f10"), Status = MandateUpdateStatusType.Withdrawn }// existing batch ID
            };
        
            // Act
            var response = client.UpdateMandateStatus(request);

            // Assert
            Assert.IsNotNull(response, "Response is null.");
            Assert.IsNull(response.Error, "An error is returned: " + (response.Error != null ? response.Error.Description : string.Empty));
        }

        [TestMethod]
        [TestCategory("Mandates")]
        public void UpdateMandateStatus_Batch_ErrorResponse_Test()
        {
            // Arrange
            var client = new AEServiceClient();

            var request = new UpdateMandateRecordsStatusRequestType()
            {
                Item = new BatchMandateStatusUpdateRequest() { BatchID = new Guid("37fe7c59-4786-4825-8d5d-222bb0e25f10"), Status = MandateUpdateStatusType.Withdrawn }// non existing batch ID
            };

            // Act
            var response = client.UpdateMandateStatus(request);

            // Assert
            Assert.IsNotNull(response, "Response is null.");
            Assert.IsNotNull(response.Error, "No error was returned");
        }
    }
}