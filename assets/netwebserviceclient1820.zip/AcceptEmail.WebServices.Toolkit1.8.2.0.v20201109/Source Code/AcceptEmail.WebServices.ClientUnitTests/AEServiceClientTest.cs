﻿using System;
using System.Linq;
using AcceptEmail.WebServices.ClientLibrary.AeApi;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace AcceptEmail.WebServices.ClientUnitTests
{


    /// <summary>
    ///This is a test class for AEServiceClientTest and is intended
    ///to contain all AEServiceClientTest Unit Tests
    ///</summary>
    [TestClass]
    public class AEServiceClientTest
    {
        public AEServiceClientTest()
        {
            System.Net.ServicePointManager.SecurityProtocol = (System.Net.SecurityProtocolType)3072;
        }

        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        [ClassInitialize()]
        public static void MyClassInitialize(TestContext testContext)
        {
        }
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion

        public void CreateBatchSinglePartHelper()
        {
            AEServiceClient client = new AEServiceClient();

            string senderBatchReferenceID = "WST" + DateTime.Now.ToString("yyMMddHHmmss") + Guid.NewGuid().ToString().Substring(0, 5);

            //default parameter values
            string file = @"batch-01invoices+EmailData.csv";

            //check the Test Context for parameter values
            if (TestContext.Properties.Contains("CreateBatchSinglePart-FileName"))
            {
                file = (string)TestContext.Properties["CreateBatchSinglePart-FileName"];
            }

            /*
             * Create
             */
            //Parse the CSV file and extract an array of RecordRequests
            RecordRequest[] records = AEHelper.GetRecordRequestFromCSVFile(file);
            int recordCount = records.Length;
            CreateBatchRequestType createBatchRequest;
            CreateBatchResponseType createBatchResponse = new CreateBatchResponseType();

            createBatchRequest = AEHelper.InitializeCreateBatchRequestType(senderBatchReferenceID, recordCount);
            createBatchRequest.Records = records;

            createBatchResponse = client.CreateBatch(createBatchRequest);
            Assert.IsNotNull(createBatchResponse, "Response is null.");
            Assert.IsNull(createBatchResponse.Error, "An error is returned: " + (createBatchResponse.Error != null ? createBatchResponse.Error.Description : string.Empty));
            Assert.IsNotNull(createBatchResponse.Response, "Response.Response is null");
            Assert.IsTrue(createBatchRequest.SenderBatchReferenceID == createBatchResponse.Response.SenderBatchReferenceID, "Invalid SenderBatchReferenceID");
            Assert.IsNotNull(createBatchResponse.Response.BatchID, "BatchID is not returned.");
            Assert.IsTrue(createBatchResponse.Response.Records.Length == createBatchRequest.Records.Length, "No of inserted records is not equal with the sent records.");

            CreateBatchSinglePartHelper_CreateBatchRequest = createBatchRequest;
            CreateBatchSinglePartHelper_CreateBatchResponse = createBatchResponse;
            CreateBatchSinglePartHelper_Initialized = true;
        }

        public void CreateAndSendBatchSinglePartHelper()
        {
            if (!CreateBatchSinglePartHelper_Initialized)
            {
                CreateBatchSinglePartHelper();
            }
            AEServiceClient client = new AEServiceClient();
            var sendRequest = new SendBatchRequestType();
            sendRequest.SenderBatchReferenceID = CreateBatchSinglePartHelper_CreateBatchRequest.SenderBatchReferenceID;

            var sendRequestResponse = client.SendBatch(sendRequest);

            Assert.IsNotNull(sendRequestResponse, "SendBatchTest: Response is null.");
            Assert.IsNull(sendRequestResponse.Error, "SendBatchTest: An error is returned: " + (sendRequestResponse.Error != null ? sendRequestResponse.Error.Description : string.Empty));
            Assert.IsNotNull(sendRequestResponse.MailingID, "SendBatchTest: MailingID is null.");

            CreateAndSendBatchSinglePartHelper_SendBatchRequest = sendRequest;
            CreateAndSendBatchSinglePartHelper_SendBatchResponse = sendRequestResponse;
            CreateAndSendBatchSinglePartHelper_Initialized = true;
        }

        /// <summary>
        ///A test for CreateBatch
        ///</summary>
        [TestMethod()]
        public void CreateBatchSinglePartTest()
        {
            CreateBatchSinglePartHelper();
        }

        [TestMethod()]
        public void CreateBatchMultiplePartsTest()
        {
            AEServiceClient client = new AEServiceClient();

            string senderBatchReferenceID = "WST" + DateTime.Now.ToString("yyMMddHHmmss") + Guid.NewGuid().ToString().Substring(0, 5);

            //default parameter values
            string file = @"batch-10invoices+EmailData.csv";
            int secondsBetweenCalls = 5;
            int invPerCreateBatch = 3;

            //check the Test Context for parameter values
            if (TestContext.Properties.Contains("CreateBatchMultiplePartsTest-FileName"))
            {
                file = (string)TestContext.Properties["CreateBatchMultiplePartsTest-FileName"];
            }
            if (TestContext.Properties.Contains("CreateBatchMultiplePartsTest-SecondsBetweenCalls"))
            {
                secondsBetweenCalls = Int32.Parse((string)TestContext.Properties["CreateBatchMultiplePartsTest-SecondsBetweenCalls"]);
            }
            if (TestContext.Properties.Contains("CreateBatchMultiplePartsTest-InvPerCreateBatch"))
            {
                invPerCreateBatch = Int32.Parse((string)TestContext.Properties["CreateBatchMultiplePartsTest-InvPerCreateBatch"]);
            }

            /*
             * Create
             */
            //Parse the CSV file and extract an array of RecordRequests
            RecordRequest[] records = AEHelper.GetRecordRequestFromCSVFile(file);
            int recordCount = records.Length;
            CreateBatchRequestType createBatchRequest;
            CreateBatchResponseType createBatchResponse = new CreateBatchResponseType();

            int steps = (int)Math.Ceiling((double)recordCount / (double)invPerCreateBatch);
            for (int i = 0; i < steps - 1; ++i)
            {
                createBatchRequest = AEHelper.InitializeCreateBatchRequestType(senderBatchReferenceID, invPerCreateBatch);
                Array.Copy(records, i * invPerCreateBatch, createBatchRequest.Records, 0, invPerCreateBatch);
                //if this is the last iteration of the loop, don't sleep
                if (i != steps - 2)
                {
                    System.Threading.Thread.Sleep(secondsBetweenCalls * 1000);
                }

                createBatchResponse = client.CreateBatch(createBatchRequest);
                Assert.IsNotNull(createBatchResponse, "Response is null.");
                Assert.IsNull(createBatchResponse.Error, "An error is returned: " + (createBatchResponse.Error != null ? createBatchResponse.Error.Description : string.Empty));
                Assert.IsNotNull(createBatchResponse.Response, "Response.Response is null");
                Assert.IsTrue(createBatchRequest.SenderBatchReferenceID == createBatchResponse.Response.SenderBatchReferenceID, "Invalid SenderBatchReferenceID");
                Assert.IsNotNull(createBatchResponse.Response.BatchID, "BatchID is not returned.");
                Assert.IsTrue(createBatchResponse.Response.Records.Length == createBatchRequest.Records.Length, "No of inserted records is not equal with the sent records.");
            }

            //the last CreateBatchRequestType might have less records
            int remainingRecords = recordCount - (steps - 1) * invPerCreateBatch;
            if (remainingRecords > 0)
            {
                System.Threading.Thread.Sleep(secondsBetweenCalls * 1000);
                createBatchRequest = AEHelper.InitializeCreateBatchRequestType(senderBatchReferenceID, remainingRecords);
                Array.Copy(records, invPerCreateBatch * (steps - 1), createBatchRequest.Records, 0, remainingRecords);
                createBatchResponse = client.CreateBatch(createBatchRequest);

                Assert.IsNotNull(createBatchResponse, "Response is null.");
                Assert.IsNull(createBatchResponse.Error, "An error is returned: " + (createBatchResponse.Error != null ? createBatchResponse.Error.Description : string.Empty));
                Assert.IsNotNull(createBatchResponse.Response, "Response.Response is null");
                Assert.IsTrue(createBatchRequest.SenderBatchReferenceID == createBatchResponse.Response.SenderBatchReferenceID, "Invalid SenderBatchReferenceID");
                Assert.IsNotNull(createBatchResponse.Response.BatchID, "BatchID is not returned.");
                Assert.IsTrue(createBatchResponse.Response.Records.Length == createBatchRequest.Records.Length, "No of inserted records is not equal with the sent records.");
            }
        }

        /// <summary>
        ///A test for SendBatch
        ///</summary>
        [TestMethod()]
        public void SendBatchTest()
        {
            CreateAndSendBatchSinglePartHelper();
        }

        /// <summary>
        ///A test for GetUnsubscribedAddresses
        ///</summary>
        [TestMethod()]
        public void GetUnsubscribedAddressesWithStartDateTest()
        {
            AEServiceClient client = new AEServiceClient();

            var request = new GetUnsubscribedAddressesRequestType();
            request.StartDateTime = DateTime.Now.AddMonths(-3);

            var response = client.GetUnsubscribedAddresses(request);

            Assert.IsNotNull(response, "UnsubscribedAddressesRequest: Response is null.");
            Assert.IsNull(response.Error, "UnsubscribedAddressesRequest: An error is returned: " + (response.Error != null ? response.Error.Description : string.Empty));
            Assert.IsNotNull(response.Records, "UnsubscribedAddressesRequest: The Records list is null.");
        }

        [TestMethod]
        public void GetUnsubscribedAddressesWithStartDateAndEndDate()
        {
            AEServiceClient client = new AEServiceClient();

            var request = new GetUnsubscribedAddressesRequestType();
            request.StartDateTime = DateTime.Now.AddMonths(-3);
            request.EndDateTime = DateTime.Now;

            var response = client.GetUnsubscribedAddresses(request);

            Assert.IsNotNull(response, "UnsubscribedAddressesRequest: Response is null.");
            Assert.IsNull(response.Error, "UnsubscribedAddressesRequest: An error is returned: " + (response.Error != null ? response.Error.Description : string.Empty));
            Assert.IsNotNull(response.Records, "UnsubscribedAddressesRequest: The Records list is null.");
        }

        [TestMethod]
        public void GetUnsubscribedAddressesWithInvalidStartDateAndEndDate()
        {
            AEServiceClient client = new AEServiceClient();

            var request = new GetUnsubscribedAddressesRequestType();
            request.StartDateTime = DateTime.Now.AddMilliseconds(100);
            request.EndDateTime = DateTime.Now;

            var response = client.GetUnsubscribedAddresses(request);

            Assert.IsNotNull(response, "UnsubscribedAddressesRequest: Response is null.");
            Assert.IsNotNull(response.Error, "UnsubscribedAddressesRequest: Error is null.");
            Assert.IsNull(response.Records, "UnsubscribedAddressesRequest: The Records list is not null.");
            Assert.IsTrue(response.Error.Code == "AEWS_APP0219", "UnsubscribedAddressesRequest: The Error code is not AEWS_APP0219.");
        }

        /// <summary>
        ///A test for GetDeliveryReport
        ///</summary>
        [TestMethod()]
        public void GetDeliveryReportTest()
        {
            AEServiceClient client = new AEServiceClient();

            var request = new GetDeliveryReportRequestType();
            request.StartDateTime = DateTime.Now.AddYears(-1);
            var response = client.GetDeliveryReport(request);

            Assert.IsNotNull(response, "DeliveryReportRequest: Response is null.");
            Assert.IsNull(response.Error, "DeliveryReportRequest: An error is returned: " + (response.Error != null ? response.Error.Description : string.Empty));
        }

        /// <summary>
        ///A test for GetMailingStatus
        ///</summary>
        [TestMethod()]
        public void GetMailingStatusTest()
        {
            AEServiceClient client = new AEServiceClient();

            if (!CreateAndSendBatchSinglePartHelper_Initialized)
            {
                CreateAndSendBatchSinglePartHelper();
            }
            var mailingID = CreateAndSendBatchSinglePartHelper_SendBatchResponse.MailingID;


            var request = new GetMailingStatusRequestType();
            request.MailingID = mailingID.Value;


            var response = client.GetMailingStatus(request);

            Assert.IsNotNull(response, "MailingStatusRequest: Response is null.");
            Assert.IsNull(response.Error, "MailingStatusRequest: An error is returned: " + (response.Error != null ? response.Error.Description : string.Empty));
            Assert.IsNotNull(response.Response, "MailingStatusRequest: Response is null.");
        }

        /// <summary>
        ///A test for UpdateDeliveryReport
        ///</summary>
        [TestMethod()]
        public void UpdateDeliveryReportTest()
        {
            AEServiceClient client = new AEServiceClient();

            if (!CreateAndSendBatchSinglePartHelper_Initialized)
            {
                CreateAndSendBatchSinglePartHelper();
            }

            var initRequest = CreateBatchSinglePartHelper_CreateBatchRequest;
            var initRequestResponse = CreateBatchSinglePartHelper_CreateBatchResponse;

            var request = new UpdateDeliveryReportRequestType();
            request.Records = new UpdateDeliveryReportRequestRecord[1];
            request.Records[0] = new UpdateDeliveryReportRequestRecord()
            {
                RecordATID = initRequestResponse.Response.Records[0].RecordATID,
                StatusCode = "4.7.2",
                DateReceived = DateTime.Now.AddDays(-1),
                EmailAddress = initRequest.Records[0].EmailAddress
            };


            var response = client.UpdateDeliveryReport(request);

            Assert.IsNotNull(response, "DeliveryUpdateRequest: Response is null.");
            Assert.IsNull(response.Error, "DeliveryUpdateRequest: An error is returned: " + (response.Error != null ? response.Error.Description : string.Empty));
            Assert.IsTrue(response.Count == 1, "DeliveryUpdateRequest: The Count is different than 1.");

        }


        /// <summary>
        ///A test for GetAcceptEmailTemplates
        ///</summary>
        [TestMethod()]
        public void GetAcceptEmailTemplatesTest()
        {
            AEServiceClient client = new AEServiceClient();

            var response = client.GetAcceptEmailTemplates(
                new GetAcceptEmailTemplatesRequestType { ProductID = null });

            Assert.IsNotNull(response);
            Assert.IsNotNull(response.AcceptEmailTemplates);
            Assert.IsNull(response.Error, "An error is returned: " + (response.Error != null ? response.Error.Description : string.Empty));
            Assert.IsTrue(response.AcceptEmailTemplates.Length > 0);
        }

        /// <summary>
        ///A test for GetEmailTemplates
        ///</summary>
        [TestMethod()]
        public void GetEmailTemplatesTest()
        {
            AEServiceClient client = new AEServiceClient();
            var response = client.GetEmailTemplates();
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.EmailTemplates);
            Assert.IsNull(response.Error, "An error is returned: " + (response.Error != null ? response.Error.Description : string.Empty));
            Assert.IsTrue(response.EmailTemplates.Length > 0);
        }

        /// <summary>
        ///A test for GetFinancialReport
        ///</summary>
        [TestMethod()]
        public void GetFinancialReportTest()
        {
            AEServiceClient client = new AEServiceClient();

            if (!CreateAndSendBatchSinglePartHelper_Initialized)
            {
                CreateAndSendBatchSinglePartHelper();
            }

            var request = new GetFinancialReportRequestType();
            request.StartDateTime = DateTime.Now.AddMonths(-3);

            var response = client.GetFinancialReport(request);

            Assert.IsNotNull(response, "FinancialReportRequest: Response is null.");
            Assert.IsNull(response.Error, "FinancialReportRequest: An error is returned: " + (response.Error != null ? response.Error.Description : string.Empty));
            Assert.IsNotNull(response.Records, "FinancialReportRequest: Response is null.");
        }

        /// <summary>
        ///A test for RemoveUnsubscribedAddresses
        ///</summary>
        [TestMethod()]
        public void RemoveUnsubscribedAddressesTest()
        {
            AEServiceClient client = new AEServiceClient();

            var request = new RemoveUnsubscribedAddressesRequestType();
            request.EmailAddresses = new string[1];
            request.EmailAddresses[0] = "test@dev.abcpress.com";

            var response = client.RemoveUnsubscribedAddresses(request);
            Assert.IsNotNull(response, "UnsubscribedAddressesRemoveRequest: Response is null.");
            Assert.IsNull(response.Error, "UnsubscribedAddressesRemoveRequest: An error is returned: " + (response.Error != null ? response.Error.Description : string.Empty));
        }


        /// <summary>
        ///A test for CreateRecord
        ///</summary>
        [TestMethod()]
        public void CreateRecordTest()
        {
            AEServiceClient client = new AEServiceClient();

            var request = AEHelper.GetCreateRecordRequestInstance();

            var response = client.CreateRecord(request);

            Assert.IsNotNull(response, "CreateRecordRequest: Response is null.");
            Assert.IsNull(response.Error, "CreateRecordRequest: An error is returned: " + (response.Error != null ? response.Error.Description : string.Empty));
            Assert.IsNotNull(response.Response, "CreateRecordRequest: Response.Response is null");
            Assert.IsNotNull(response.Response.RecordATID, "CreateRecordRequest: RecordATID is null.");
            Assert.IsTrue(response.Response.SenderRecordReferenceID == request.SenderRecordReferenceID, "CreateRecordRequest: The invoice returned is not the same with the one sent.");

        }


        /// <summary>
        ///A test for GetRecordsStatus. Must have Snooze Right
        ///</summary>
        [TestMethod()]
        public void GetRecordsStatusByBatchWithSnoozeRightTest()
        {
            AEServiceClient client = new AEServiceClient();

            if (!CreateAndSendBatchSinglePartHelper_Initialized)
            {
                CreateAndSendBatchSinglePartHelper();
            }

            var statusRequestRequest = new GetRecordsStatusRequestType
            {
                Item = CreateBatchSinglePartHelper_CreateBatchResponse.Response.BatchID,
                ReturnDetails = true
            };

            var statusRequestResponse = client.GetRecordsStatus(statusRequestRequest);

            Assert.IsNotNull(statusRequestResponse, "StatusRequest: statusRequestResponse is null.");
            Assert.IsNull(statusRequestResponse.Error, "StatusRequest: An error is returned: " + (statusRequestResponse.Error != null ? statusRequestResponse.Error.Description : string.Empty));
            Assert.IsNotNull(statusRequestResponse.Records, "StatusRequest: Records is null.");
            Assert.IsNotNull(statusRequestResponse.Records[0].Details.Amount.Value, "Amount value should not be null");

            var firstInvoiceRecordATID = CreateBatchSinglePartHelper_CreateBatchResponse.Response.Records[0].RecordATID;

            Assert.IsTrue(statusRequestResponse.Records.Where(r => r.RecordATID == firstInvoiceRecordATID).ToList().Count > 0, "StatusRequest: Cannot find status details for the first invoice.");
            Assert.IsNotNull(statusRequestResponse.Records[0].Details.Snoozes);
        }


        [TestMethod()]
        public void GetRecordsStatusByBatchTest()
        {
            AEServiceClient client = new AEServiceClient();

            if (!CreateAndSendBatchSinglePartHelper_Initialized)
            {
                CreateAndSendBatchSinglePartHelper();
            }

            var statusRequestRequest = new GetRecordsStatusRequestType
            {
                Item = CreateBatchSinglePartHelper_CreateBatchResponse.Response.BatchID,
                ReturnDetails = true
            };

            var statusRequestResponse = client.GetRecordsStatus(statusRequestRequest);

            Assert.IsNotNull(statusRequestResponse, "StatusRequest: statusRequestResponse is null.");
            Assert.IsNull(statusRequestResponse.Error, "StatusRequest: An error is returned: " + (statusRequestResponse.Error != null ? statusRequestResponse.Error.Description : string.Empty));
            Assert.IsNotNull(statusRequestResponse.Records, "StatusRequest: Records is null.");
            Assert.IsNotNull(statusRequestResponse.Records[0].Details.Amount.Value, "Amount value should not be null");

            var firstInvoiceRecordATID = CreateBatchSinglePartHelper_CreateBatchResponse.Response.Records[0].RecordATID;

            Assert.IsTrue(statusRequestResponse.Records.Where(r => r.RecordATID == firstInvoiceRecordATID).ToList().Count > 0, "StatusRequest: Cannot find status details for the first invoice.");
        }

        [TestMethod]
        public void GetRecordsStatusByEmailTest()
        {
            AEServiceClient client = new AEServiceClient();

            if (!CreateAndSendBatchSinglePartHelper_Initialized)
            {
                CreateAndSendBatchSinglePartHelper();
            }

            var statusRequestRequest = new GetRecordsStatusRequestType()
            {
                Item = "test@dev.abcpress.com",
                ReturnDetails = true,
                ItemElementName = ItemChoiceType.EmailAddress
            };

            var statusRequestResponse = client.GetRecordsStatus(statusRequestRequest);

            Assert.IsNotNull(statusRequestResponse, "StatusRequest: statusRequestResponse is null.");
            Assert.IsNull(statusRequestResponse.Error, "StatusRequest: An error is returned: " + (statusRequestResponse.Error != null ? statusRequestResponse.Error.Description : string.Empty));
            Assert.IsNotNull(statusRequestResponse.Records, "StatusRequest: Records is null.");
        }


        [TestMethod]
        public void GetRecordsStatusByRecords()
        {
            AEServiceClient client = new AEServiceClient();

            if (!CreateAndSendBatchSinglePartHelper_Initialized)
            {
                CreateAndSendBatchSinglePartHelper();
            }

            var statusRequestRequest = new GetRecordsStatusRequestType()
            {
                Item = (from i in CreateBatchSinglePartHelper_CreateBatchResponse.Response.Records select i.RecordATID).ToArray(),
                ReturnDetails = true,
                ItemElementName = ItemChoiceType.RecordATIDs
            };

            var statusRequestResponse = client.GetRecordsStatus(statusRequestRequest);

            Assert.IsNotNull(statusRequestResponse, "StatusRequestByRecords: statusRequestResponse is null.");
            Assert.IsNull(statusRequestResponse.Error, "StatusRequestByRecords: An error is returned: " + (statusRequestResponse.Error != null ? statusRequestResponse.Error.Description : string.Empty));
            Assert.IsNotNull(statusRequestResponse.Records, "StatusRequestByRecords: Records is null.");

            var firstInvoiceRecordATID = CreateBatchSinglePartHelper_CreateBatchResponse.Response.Records[0].RecordATID;

            Assert.IsTrue(statusRequestResponse.Records.Where(r => r.RecordATID == firstInvoiceRecordATID).ToList().Count > 0, "StatusRequest: Cannot find status details for the first invoice.");
        }

        [TestMethod]
        public void GetRecordsStatusByCreationDateIntervalPaged()
        {
            AEServiceClient client = new AEServiceClient();

            if (!CreateAndSendBatchSinglePartHelper_Initialized)
            {
                CreateAndSendBatchSinglePartHelper();
            }

            var statusRequestRequest = new GetRecordsStatusRequestType()
            {
                Item = new PagedDateTimeIntervalFilter
                {
                    StartDate = DateTime.Now,
                    EndDate = DateTime.Now.AddYears(1),
                    StartDateSpecified = true,
                    EndDateSpecified = true,
                    Skip = 0,
                    SkipSpecified = true,
                    Take = 10,
                    TakeSpecified = true
                },
                ReturnDetails = true,
                ItemElementName = ItemChoiceType.PagedCreationInterval
            };

            var statusRequestResponse = client.GetRecordsStatus(statusRequestRequest);

            Assert.IsNotNull(statusRequestResponse, "GetRecordsStatusByCreationDateIntervalPaged: statusRequestResponse is null.");
            Assert.IsNull(statusRequestResponse.Error, "GetRecordsStatusByCreationDateIntervalPaged: An error is returned: " + (statusRequestResponse.Error != null ? statusRequestResponse.Error.Description : string.Empty));
            Assert.IsNotNull(statusRequestResponse.Records, "GetRecordsStatusByCreationDateIntervalPaged: Records is null.");
        }

        [TestMethod]
        public void GetRecordsStatusByExpirationDateIntervalPaged()
        {
            AEServiceClient client = new AEServiceClient();

            if (!CreateAndSendBatchSinglePartHelper_Initialized)
            {
                CreateAndSendBatchSinglePartHelper();
            }

            var statusRequestRequest = new GetRecordsStatusRequestType()
            {
                Item = new PagedDateTimeIntervalFilter
                {
                    StartDate = DateTime.Now,
                    EndDate = DateTime.Now.AddYears(1),
                    StartDateSpecified = true,
                    EndDateSpecified = true,
                    Skip = 0,
                    SkipSpecified = true,
                    Take = 10,
                    TakeSpecified = true
                },
                ReturnDetails = true,
                ItemElementName = ItemChoiceType.PagedExpirationInterval
            };

            var statusRequestResponse = client.GetRecordsStatus(statusRequestRequest);

            Assert.IsNotNull(statusRequestResponse, "GetRecordsStatusByCreationDateIntervalPaged: statusRequestResponse is null.");
            Assert.IsNull(statusRequestResponse.Error, "GetRecordsStatusByCreationDateIntervalPaged: An error is returned: " + (statusRequestResponse.Error != null ? statusRequestResponse.Error.Description : string.Empty));
            Assert.IsNotNull(statusRequestResponse.Records, "GetRecordsStatusByCreationDateIntervalPaged: Records is null.");
        }


        /// <summary>
        ///A test for UpdateRecordsStatus
        ///</summary>
        [TestMethod()]
        public void UpdateRecordsStatusRecordLevelTest()
        {
            AEServiceClient client = new AEServiceClient();

            CreateBatchSinglePartHelper_Initialized = false;
            CreateAndSendBatchSinglePartHelper_Initialized = false;

            //Create a new batch (in order to udpate its status to paid)
            CreateAndSendBatchSinglePartHelper();

            var initRequestResponse = CreateBatchSinglePartHelper_CreateBatchResponse;

            Assert.IsNotNull(initRequestResponse);
            Assert.IsNotNull(initRequestResponse.Response);
            Assert.IsNotNull(initRequestResponse.Response.Records);



            var statusUpdateRequestRequest = new UpdateRecordsStatusRequestType()
            {
                //change the status to Paid
                Item = (from i in initRequestResponse.Response.Records select new RecordStatusUpdateRequest() { RecordATID = i.RecordATID, StatusID = 2 }).ToArray()
            };

            var statusUpdateRequestResponse = client.UpdateRecordsStatus(statusUpdateRequestRequest);

            Assert.IsNotNull(statusUpdateRequestResponse, "StatusUpdateRequest: statusUpdateRequestResponse is null.");
            Assert.IsNull(statusUpdateRequestResponse.Error, "StatusUpdateRequest: An error is returned: " + (statusUpdateRequestResponse.Error != null ? statusUpdateRequestResponse.Error.Description : string.Empty));

            var firstInvoice = initRequestResponse.Response.Records[0];

            Assert.IsTrue(statusUpdateRequestResponse.Records.Where(r => r.RecordATID == firstInvoice.RecordATID).ToList().Count > 0, "StatusUpdateRequest: Cannot find status details for the first invoice.");
            Assert.IsTrue(statusUpdateRequestResponse.Records.Where(r => r.RecordATID == firstInvoice.RecordATID).FirstOrDefault().StatusUpdate.Updated != null, "StatusUpdateRequest: The first invoice status is not updated.");

        }

        [TestMethod()]
        public void UpdateRecordsStatusBatchLevelTest()
        {
            AEServiceClient client = new AEServiceClient();

            CreateBatchSinglePartHelper_Initialized = false;
            CreateAndSendBatchSinglePartHelper_Initialized = false;

            //Create a new batch (in order to udpate its status to paid)
            CreateAndSendBatchSinglePartHelper();


            var initRequestResponse = CreateBatchSinglePartHelper_CreateBatchResponse;

            Assert.IsNotNull(initRequestResponse);
            Assert.IsNotNull(initRequestResponse.Response);
            Assert.IsNotNull(initRequestResponse.Response.Records);



            var statusUpdateRequestRequest = new UpdateRecordsStatusRequestType()
            {
                //change the status to Paid
                Item = new BatchStatusUpdateRequest() { BatchID = initRequestResponse.Response.BatchID, StatusID = 2 }
            };

            var statusUpdateRequestResponse = client.UpdateRecordsStatus(statusUpdateRequestRequest);

            Assert.IsNotNull(statusUpdateRequestResponse, "StatusUpdateRequest: statusUpdateRequestResponse is null.");
            Assert.IsNull(statusUpdateRequestResponse.Error, "StatusUpdateRequest: An error is returned: " + (statusUpdateRequestResponse.Error != null ? statusUpdateRequestResponse.Error.Description : string.Empty));

            var firstInvoice = initRequestResponse.Response.Records[0];

            Assert.IsTrue(statusUpdateRequestResponse.Records.Where(r => r.RecordATID == firstInvoice.RecordATID).ToList().Count > 0, "StatusUpdateRequest: Cannot find status details for the first invoice.");
            Assert.IsTrue(statusUpdateRequestResponse.Records.Where(r => r.RecordATID == firstInvoice.RecordATID).FirstOrDefault().StatusUpdate.Updated != null, "StatusUpdateRequest: The first invoice status is not updated.");

        }


        /// <summary>
        ///A test for GetConversionWaterfallReport
        ///</summary>
        [TestMethod()]
        public void GetConversionWaterfallReportTest()
        {
            AEServiceClient client = new AEServiceClient();

            if (!CreateAndSendBatchSinglePartHelper_Initialized)
            {
                CreateAndSendBatchSinglePartHelper();
            }

            var request = new GetConversionWaterfallReportRequestType();
            request.StartDateTime = DateTime.Now.AddMonths(-1);
            var response = client.GetConversionWaterfallReport(request);

            Assert.IsNotNull(response, "GetConversionWaterfallRequest: Response is null.");
            Assert.IsNull(response.Error, "GetConversionWaterfallRequest: An error is returned: " + (response.Error != null ? response.Error.Description : string.Empty));
            Assert.IsNotNull(response.Report, "GetConversionWaterfallRequest: Report is null.");
        }


        /// <summary>
        ///A test for GetBatchRecords
        ///</summary>
        [TestMethod()]
        public void GetBatchRecordsTest()
        {
            AEServiceClient client = new AEServiceClient();

            if (!CreateAndSendBatchSinglePartHelper_Initialized)
            {
                CreateAndSendBatchSinglePartHelper();
            }

            GetBatchRecordsRequestType request = new GetBatchRecordsRequestType();
            request.Item = CreateAndSendBatchSinglePartHelper_SendBatchRequest.SenderBatchReferenceID;

            GetBatchRecordsResponseType response;
            response = client.GetBatchRecords(request);
            Assert.IsNotNull(response, "GetBatchRecords: Response is null.");
            Assert.IsNull(response.Error, "GetBatchRecords: An error is returned: " + (response.Error != null ? response.Error.Description : string.Empty));
            Assert.IsNotNull(response.Response, "GetBatchRecords: Records Array is null.");

            Assert.IsTrue(response.Response.Records.Count() == CreateBatchSinglePartHelper_CreateBatchRequest.Records.Count(),
                "GetBatchRecords: The number of returned records does not match the number of sent records");

            if (response.Response.Records.Count() > 0)
            {
                Assert.IsTrue(response.Response.Records[0].RecordATID == CreateBatchSinglePartHelper_CreateBatchResponse.Response.Records[0].RecordATID,
                    "GetBatchRecords: The ATIDs form the first records in the two record arrays do not match");
            }

        }

        /// <summary>
        ///A test for GetRecordDetails
        ///</summary>
        [TestMethod()]
        public void GetRecordDetailsTest()
        {
            AEServiceClient client = new AEServiceClient();

            if (!CreateAndSendBatchSinglePartHelper_Initialized)
            {
                CreateAndSendBatchSinglePartHelper();
            }

            if (CreateBatchSinglePartHelper_CreateBatchResponse.Response.Records.Count() > 0)
            {
                var record = CreateBatchSinglePartHelper_CreateBatchResponse.Response.Records[0];
                GetRecordDetailsRequestType request = new GetRecordDetailsRequestType();
                request.RecordATID = record.RecordATID;
                GetRecordDetailsResponseType response;
                response = client.GetRecordDetails(request);

                Assert.IsNotNull(response, "GetRecordDetails: Response is null.");
                Assert.IsNull(response.Error, "GetRecordDetails: An error is returned: " + (response.Error != null ? response.Error.Description : string.Empty));
                Assert.IsNotNull(response.Record, "GGetRecordDetails: Record is null.");
                Assert.IsTrue(record.SenderRecordReferenceID == response.Record.SenderRecordReferenceID,
                    "GetRecordDetailsTest: SRRIDs do not match ");
            }
        }

        #region Test Context Properties

        private static CreateBatchRequestType CreateBatchSinglePartHelper_CreateBatchRequest
        {
            get;
            set;
        }

        private static CreateBatchResponseType CreateBatchSinglePartHelper_CreateBatchResponse
        {
            get;
            set;
        }

        private static SendBatchRequestType CreateAndSendBatchSinglePartHelper_SendBatchRequest
        {
            get;
            set;
        }

        private static SendBatchResponseType CreateAndSendBatchSinglePartHelper_SendBatchResponse
        {
            get;
            set;
        }

        private static bool CreateBatchSinglePartHelper_Initialized
        {
            get;
            set;
        }

        private static bool CreateAndSendBatchSinglePartHelper_Initialized
        {
            get;
            set;
        }
        #endregion

    }
}
