﻿using System;
using System.Collections.Generic;
using System.IO;

using AcceptEmail.WebServices.ClientLibrary.AeApi;


namespace AcceptEmail.WebServices.ClientUnitTests
{
	class AEHelper
	{

		#region Test data helpers

		public static RecordRequest[] GetRecordRequestFromCSVFile(string file)
		{
			StreamReader strRdr = new StreamReader(file);
			//skip the first line (int contains the table headers)
			strRdr.ReadLine();

			string inputLine = "";
			List<RecordRequest> records = new List<RecordRequest>();

			//int recordCount = 0;
			while ((inputLine = strRdr.ReadLine()) != null)
			{
				String[] values = inputLine.Split(';');
				RecordRequest recordRequest = new RecordRequest();
				recordRequest.SenderRecordReferenceID = values[0];
				recordRequest.PaymentReference = values[1];
				recordRequest.Description = values[2];
				recordRequest.Amount = new Amount();
				recordRequest.Amount.Value = values[3];
				recordRequest.EmailAddress = values[4];
				recordRequest.CountdownDays = Int32.Parse(values[5]);
				recordRequest.DateTime = DateTime.Parse(values[6]);
				recordRequest.EmailData = new KeyValuePair[7];

				records.Add(recordRequest);
			}
			strRdr.Close();
			return records.ToArray();
		}

		public static CreateBatchRequestType InitializeCreateBatchRequestType(string senderBatchReferenceID, int nrOfRecords)
		{
			CreateBatchRequestType createBatchRequest = new CreateBatchRequestType();
			createBatchRequest.SenderBatchReferenceID = senderBatchReferenceID;
			createBatchRequest.BatchValues = new BatchValues();
			createBatchRequest.BatchValues.AcceptEmailTemplateID = null;
			createBatchRequest.BatchValues.ProductID = null;
			createBatchRequest.Records = new RecordRequest[nrOfRecords];
			return createBatchRequest;
		}

		public static CreateRecordRequestType GetCreateRecordRequestInstance()
		{
			var record = new CreateRecordRequestType();
			record.SenderRecordReferenceID = "SRRID-WSTK" + DateTime.Now.ToString("HHmmss");
			record.PaymentReference = "PR-WSTK";
			record.Description = "WSToolKit" + DateTime.Now.ToString("HHmmss");
			record.Amount = new Amount();
			record.Amount.Value = "150";
			record.EmailAddress = "test@dev.abcpress.com";
			record.CountdownDays = 1;
			record.DateTime = DateTime.Now.AddDays(1);
		    record.ReturnBannerOpenURL = "http://acceptemail.com";
            record.ReturnBannerPaidURL = "http://acceptemail.com";
			record.EmailData = new KeyValuePair[7];
			record.EmailData[0] = new KeyValuePair();
			record.EmailData[0].Key = "recipientDisplayName";
			record.EmailData[0].Value = "Mr. JJ WSToolKit";
			record.EmailData[1] = new KeyValuePair();
			record.EmailData[1].Key = "recipientAddressLine1";
			record.EmailData[1].Value = "12 WSToolKit street";
			record.EmailData[2] = new KeyValuePair();
			record.EmailData[2].Key = "recipientAddressLine2";
			record.EmailData[2].Value = "WSToolKit village";
			record.EmailData[3] = new KeyValuePair();
			record.EmailData[3].Key = "recipientAddressLine3";
			record.EmailData[3].Value = "WSToolKit province";
			record.EmailData[4] = new KeyValuePair();
			record.EmailData[4].Key = "recipientAddressLine4";
			record.EmailData[4].Value = "WSToolKit-country";
			record.EmailData[5] = new KeyValuePair();
			record.EmailData[5].Key = "recipientAddressLine5";
			record.EmailData[5].Value = "1-800-dial-WSToolKit";
			record.EmailData[6] = new KeyValuePair();
			record.EmailData[6].Key = "invoiceDescription";
			record.EmailData[6].Value = "Invoice description WSToolKit";
			return record;
		}

		#endregion
	}
}
