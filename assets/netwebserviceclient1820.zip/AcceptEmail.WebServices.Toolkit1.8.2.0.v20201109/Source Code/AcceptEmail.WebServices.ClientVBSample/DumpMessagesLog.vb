﻿Imports AcceptEmail.WebServices.ClientLibrary.Interfaces


Public Class DumpMessagesLog
    Implements IMessageLog


    Public Sub Info(message As String) Implements IMessageLog.Info
        Console.WriteLine("Info message:" + message)
    End Sub

    Public Sub InputMessage(message As String) Implements IMessageLog.InputMessage
        Console.WriteLine("Request message:" + message)
    End Sub

    Public Sub OutputMessage(message As String) Implements IMessageLog.OutputMessage
        Console.WriteLine("Receive message:" + message)
    End Sub
End Class
