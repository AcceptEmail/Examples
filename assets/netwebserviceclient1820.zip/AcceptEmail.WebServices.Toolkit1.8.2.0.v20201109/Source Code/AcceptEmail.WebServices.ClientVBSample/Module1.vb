﻿Imports AcceptEmail.WebServices.ClientLibrary.AeApi

Module Module1

    Sub Main()
   Using client1 As New AEServiceClient()
            GetAtTemplates(client1)
        End Using

        Using client2 As New AEServiceClient(New DumpMessagesLog())
            GetAtTemplates(client2)
        End Using
        Return
    End Sub

    Sub GetAtTemplates(client As IAEService)
        Dim templates As New GetAcceptEmailTemplatesRequestType() With {.ProductID = Nothing
                                                                       }

        Dim ret = client.GetAcceptEmailTemplates(templates)

        Console.WriteLine(ret)
        If ret.Error IsNot Nothing Then
            Console.WriteLine(ret.Error.Description)
        End If


    End Sub

End Module
